"""
Stage 1: Think3Agent (Full Positional Heuristic: Material + Tomasz Michniewski PST).
Concept from Mark Liu (2025) Chapter 2, 3, & 7:
- Evaluates positional score after each 1-ply candidate move.
- Combines standard material values with Piece-Square Tables (PST).
- Rewards center control (e4, d4, e5, d5), piece development, and king safety.
"""

import random
from typing import List, Tuple
import chess
from agents.base import BaseAgent
from agents.stage1_heuristics.pst import evaluate_relative
from games.chess.board import ChessBoard


class Think3Agent(BaseAgent):
    """
    Think-3 Heuristic Agent:
    - Detects checkmate in 1-ply.
    - Evaluates all candidate moves with full static evaluation (Material + PST).
    - Plays the move yielding the highest positional score.
    """

    def __init__(self, name: str = "Think3Agent", player_id=None):
        super().__init__(name=name, player_id=player_id)

    def act(self, board: ChessBoard) -> chess.Move:
        legal_moves = board.legal_moves
        if not legal_moves:
            raise ValueError("No legal moves available!")

        best_score = -float("inf")
        best_moves: List[chess.Move] = []

        turn = board.turn

        for move in legal_moves:
            board.board.push(move)

            # If this move checkmates, prioritize it immediately
            if board.board.is_checkmate():
                board.board.pop()
                return move

            # Since board.board.push changes turn to opponent,
            # evaluation from our perspective is -evaluate_relative(board.board)
            score = -evaluate_relative(board.board)

            board.board.pop()

            if score > best_score:
                best_score = score
                best_moves = [move]
            elif score == best_score:
                best_moves.append(move)

        return random.choice(best_moves)
