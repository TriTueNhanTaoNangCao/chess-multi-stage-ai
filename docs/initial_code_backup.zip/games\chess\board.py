"""
ChessBoard implementation wrapping python-chess for FIDE-standard chess rules.
"""

from typing import List, Optional, Union
import chess
from games.base import BaseBoard


class ChessBoard(BaseBoard):
    """
    Chess board wrapper over python-chess adhering to BaseBoard interface.
    Guarantees 100% compliant FIDE rules including castling, en passant, promotions,
    threefold repetition, 50-move rule, checkmate, stalemate, and insufficient material.
    """

    def __init__(self, fen: Optional[str] = None):
        self.board = chess.Board(fen) if fen else chess.Board()

    def reset(self) -> None:
        self.board.reset()

    @property
    def legal_moves(self) -> List[chess.Move]:
        return list(self.board.legal_moves)

    def is_legal(self, move: chess.Move) -> bool:
        return move in self.board.legal_moves

    def push(self, move: Union[chess.Move, str]) -> None:
        if isinstance(move, str):
            try:
                move = self.board.parse_san(move)
            except ValueError:
                move = chess.Move.from_uci(move)
        self.board.push(move)

    def pop(self) -> chess.Move:
        return self.board.pop()

    def is_game_over(self) -> bool:
        return self.board.is_game_over(claim_draw=True)

    def is_check(self) -> bool:
        return self.board.is_check()

    def is_checkmate(self) -> bool:
        return self.board.is_checkmate()

    def is_stalemate(self) -> bool:
        return self.board.is_stalemate()

    def is_draw(self) -> bool:
        return self.is_game_over() and not self.board.is_checkmate()

    def get_result(self) -> Optional[float]:
        """
        Return outcome from White's perspective:
        +1.0: White wins
        -1.0: Black wins
         0.0: Draw
        None: Game in progress
        """
        if not self.is_game_over():
            return None
        outcome = self.board.outcome(claim_draw=True)
        if outcome is None:
            return 0.0
        if outcome.winner == chess.WHITE:
            return 1.0
        elif outcome.winner == chess.BLACK:
            return -1.0
        else:
            return 0.0

    def get_result_relative(self) -> Optional[float]:
        """
        Return outcome from current player's perspective:
        +1.0 if current player wins, -1.0 if loses, 0.0 if draw.
        """
        res = self.get_result()
        if res is None:
            return None
        return res if self.board.turn == chess.WHITE else -res

    @property
    def turn(self) -> chess.Color:
        return self.board.turn

    @property
    def current_player(self) -> int:
        """1 for White, -1 for Black."""
        return 1 if self.board.turn == chess.WHITE else -1

    @property
    def turn_name(self) -> str:
        return "White" if self.board.turn == chess.WHITE else "Black"

    def fen(self) -> str:
        return self.board.fen()

    def copy(self) -> "ChessBoard":
        new_b = ChessBoard()
        new_b.board = self.board.copy()
        return new_b

    def san(self, move: chess.Move) -> str:
        return self.board.san(move)

    def parse_san(self, san_str: str) -> chess.Move:
        return self.board.parse_san(san_str)

    def parse_uci(self, uci_str: str) -> chess.Move:
        return chess.Move.from_uci(uci_str)

    def piece_at(self, square: chess.Square) -> Optional[chess.Piece]:
        return self.board.piece_at(square)

    def __str__(self) -> str:
        return str(self.board)

    def __repr__(self) -> str:
        return f"ChessBoard(fen='{self.fen()}')"
