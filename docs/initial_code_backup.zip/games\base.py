"""
Abstract Base Classes for Board Games in chess-multi-stage-ai.
"""

from abc import ABC, abstractmethod
from typing import Any, List, Optional


class BaseBoard(ABC):
    """
    Abstract interface for board game states.
    All concrete game boards (like ChessBoard) must inherit from BaseBoard.
    """

    @abstractmethod
    def reset(self) -> None:
        """Reset the board to initial starting configuration."""
        pass

    @property
    @abstractmethod
    def legal_moves(self) -> List[Any]:
        """Return list of legal moves in the current position."""
        pass

    @abstractmethod
    def push(self, move: Any) -> None:
        """Execute move on the board."""
        pass

    @abstractmethod
    def pop(self) -> Any:
        """Undo the last move."""
        pass

    @abstractmethod
    def is_game_over(self) -> bool:
        """Return True if the game is over (win, loss, or draw)."""
        pass

    @abstractmethod
    def get_result(self) -> Optional[float]:
        """
        Return the game outcome from the perspective of the current player to move,
        or +1 for White win, -1 for Black win, 0 for draw.
        """
        pass

    @property
    @abstractmethod
    def current_player(self) -> int:
        """Return current player identifier (e.g. 1 for White, 0 for Black)."""
        pass

    @abstractmethod
    def copy(self) -> "BaseBoard":
        """Return a deep copy of the board."""
        pass
