"""
Stage 1: Think1Agent (1-ply Immediate Checkmate Scanner).
Concept from Mark Liu (2025) Chapter 2 & 3:
- Scans all 1-ply candidate moves.
- If any move delivers immediate checkmate, plays it right away.
- Otherwise falls back to random legal move.
"""

import random
import chess
from agents.base import BaseAgent
from games.chess.board import ChessBoard


class Think1Agent(BaseAgent):
    """Think-1-Step-Ahead Agent: finds immediate checkmate in 1-ply."""

    def __init__(self, name: str = "Think1Agent", player_id=None):
        super().__init__(name=name, player_id=player_id)

    def act(self, board: ChessBoard) -> chess.Move:
        legal_moves = board.legal_moves
        if not legal_moves:
            raise ValueError("No legal moves available!")

        # 1. Check for immediate checkmate
        for move in legal_moves:
            board.board.push(move)
            is_mate = board.board.is_checkmate()
            board.board.pop()
            if is_mate:
                return move

        # 2. Otherwise return random legal move
        return random.choice(legal_moves)
