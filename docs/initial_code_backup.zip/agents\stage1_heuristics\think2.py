"""
Stage 1: Think2Agent (Checkmate + Threat Blocking + MVV-LVA Captures).
Concept from Mark Liu (2025) Chapter 2 & 3:
- 1-ply immediate checkmate check.
- 2-ply lookahead: avoids moves that allow opponent immediate checkmate next turn.
- MVV-LVA (Most Valuable Victim - Least Valuable Attacker) capture ordering.
"""

import random
from typing import List, Tuple
import chess
from agents.base import BaseAgent
from agents.stage1_heuristics.pst import PIECE_VALUES
from games.chess.board import ChessBoard


class Think2Agent(BaseAgent):
    """
    Think-2-Steps-Ahead Agent:
    - Wins immediately if 1-ply mate exists.
    - Filters out blunders that allow opponent immediate checkmate.
    - Prioritizes lucrative captures via MVV-LVA.
    """

    def __init__(self, name: str = "Think2Agent", player_id=None):
        super().__init__(name=name, player_id=player_id)

    def _mvv_lva_score(self, board: chess.Board, move: chess.Move) -> int:
        """Calculate MVV-LVA score for a capture move."""
        if not board.is_capture(move):
            return 0

        # Victim value
        if board.is_en_passant(move):
            victim_type = chess.PAWN
        else:
            victim_piece = board.piece_at(move.to_square)
            victim_type = victim_piece.piece_type if victim_piece else chess.PAWN

        victim_val = PIECE_VALUES.get(victim_type, 0)

        # Attacker value
        attacker_piece = board.piece_at(move.from_square)
        attacker_val = PIECE_VALUES.get(attacker_piece.piece_type if attacker_piece else chess.PAWN, 0)

        # High victim, low attacker -> highest score
        return 10 * victim_val - attacker_val

    def _is_blunder_allowing_mate(self, board: chess.Board, move: chess.Move) -> bool:
        """Check if move allows opponent to checkmate on their very next turn."""
        board.push(move)
        allows_mate = False
        for opp_move in board.legal_moves:
            board.push(opp_move)
            if board.is_checkmate():
                allows_mate = True
                board.pop()
                break
            board.pop()
        board.pop()
        return allows_mate

    def act(self, board: ChessBoard) -> chess.Move:
        legal_moves = board.legal_moves
        if not legal_moves:
            raise ValueError("No legal moves available!")

        # 1. Immediate 1-ply checkmate
        for move in legal_moves:
            board.board.push(move)
            if board.board.is_checkmate():
                board.board.pop()
                return move
            board.board.pop()

        # 2. Filter out moves that allow opponent to checkmate immediately
        safe_moves = [m for m in legal_moves if not self._is_blunder_allowing_mate(board.board, m)]
        candidates = safe_moves if safe_moves else legal_moves

        # 3. MVV-LVA captures among safe moves
        captures_with_scores: List[Tuple[int, chess.Move]] = []
        for move in candidates:
            if board.board.is_capture(move):
                score = self._mvv_lva_score(board.board, move)
                captures_with_scores.append((score, move))

        if captures_with_scores:
            captures_with_scores.sort(key=lambda x: x[0], reverse=True)
            best_score = captures_with_scores[0][0]
            # Pick randomly among moves sharing top score
            best_captures = [m for s, m in captures_with_scores if s == best_score]
            return random.choice(best_captures)

        # 4. Otherwise pick random candidate move
        return random.choice(candidates)
