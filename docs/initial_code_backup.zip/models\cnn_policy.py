"""
Stage 4: Convolutional Policy Network for Chess (SL Policy & Fast Rollout).
Architectural reference: Silver et al. (Nature 2016), Mark Liu (2025) Chapter 10 & 11.
"""

from typing import Optional
import torch
import torch.nn as nn
import torch.nn.functional as F
from games.chess.encoder import NUM_ACTIONS, NUM_CHANNELS


class CNNPolicyNetwork(nn.Module):
    """
    Convolutional Neural Network predicting move probability distribution p = Pr(a|s).
    Input: (B, 18, 8, 8)
    Output: (B, 4672) logits over all AlphaZero action planes.
    """

    def __init__(self, in_channels: int = NUM_CHANNELS, num_actions: int = NUM_ACTIONS, hidden_dim: int = 128):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, hidden_dim, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(hidden_dim)

        self.conv2 = nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(hidden_dim)

        self.conv3 = nn.Conv2d(hidden_dim, hidden_dim, kernel_size=3, padding=1)
        self.bn3 = nn.BatchNorm2d(hidden_dim)

        self.fc1 = nn.Linear(hidden_dim * 8 * 8, 512)
        self.dropout = nn.Dropout(p=0.2)
        self.fc2 = nn.Linear(512, num_actions)

    def forward(self, x: torch.Tensor, legal_mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        Forward pass.
        Returns unnormalized logits or masked logits if legal_mask is provided.
        """
        out = F.relu(self.bn1(self.conv1(x)))
        out = F.relu(self.bn2(self.conv2(out)))
        out = F.relu(self.bn3(self.conv3(out)))

        out = out.reshape(out.size(0), -1)
        out = F.relu(self.fc1(out))
        out = self.dropout(out)
        logits = self.fc2(out)

        if legal_mask is not None:
            # Mask illegal moves with large negative value before softmax
            illegal = legal_mask == 0.0
            logits = logits.masked_fill(illegal, -1e9)

        return logits

    def get_action_probs(self, x: torch.Tensor, legal_mask: Optional[torch.Tensor] = None, temperature: float = 1.0) -> torch.Tensor:
        """Return normalized probabilities over legal actions."""
        logits = self.forward(x, legal_mask=legal_mask)
        if temperature != 1.0 and temperature > 0:
            logits = logits / temperature
        return F.softmax(logits, dim=-1)
