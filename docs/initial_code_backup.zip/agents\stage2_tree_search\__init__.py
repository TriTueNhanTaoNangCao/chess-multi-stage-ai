"""Stage 2: Classical Tree Search Agents."""

from agents.stage2_tree_search.minimax import MinimaxAgent
from agents.stage2_tree_search.alphabeta import AlphaBetaAgent

__all__ = ["MinimaxAgent", "AlphaBetaAgent"]
