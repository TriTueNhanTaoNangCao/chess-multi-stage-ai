"""
Baseline Random Agent that selects uniformly from legal moves.
"""

import random
import chess
from agents.base import BaseAgent
from games.chess.board import ChessBoard


class RandomAgent(BaseAgent):
    """Selects a legal move uniformly at random."""

    def __init__(self, name: str = "RandomAgent", player_id=None):
        super().__init__(name=name, player_id=player_id)

    def act(self, board: ChessBoard) -> chess.Move:
        moves = board.legal_moves
        if not moves:
            raise ValueError("No legal moves available!")
        return random.choice(moves)
