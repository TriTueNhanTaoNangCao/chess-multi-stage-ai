"""
Stage 3: Pure Monte Carlo Tree Search (MCTS) Agent.
Concepts from Mark Liu (2025) Chapter 8 & Browne et al. (2012):
- Canonical 4-step MCTS: Selection (UCB1), Expansion, Rollout (Playout), Backpropagation.
- UCB1 Exploration constant C = sqrt(2) ~ 1.414.
- Zero-sum scoring: +1 (Win), 0 (Draw), -1 (Loss).
"""

import math
import random
from typing import Dict, List, Optional
import chess
from agents.base import BaseAgent
from games.chess.board import ChessBoard


class MCTSNode:
    """A node in the pure Monte Carlo Search Tree."""

    def __init__(self, board: chess.Board, parent: Optional["MCTSNode"] = None, move: Optional[chess.Move] = None):
        self.board = board
        self.parent = parent
        self.move = move  # Move that led to this state

        self.children: Dict[chess.Move, "MCTSNode"] = {}
        self.unvisited_moves: List[chess.Move] = list(board.legal_moves)

        self.visits = 0
        self.total_value = 0.0  # From perspective of board.turn BEFORE move (player who moved here)

    def is_fully_expanded(self) -> bool:
        return len(self.unvisited_moves) == 0

    def is_terminal(self) -> bool:
        return self.board.is_game_over(claim_draw=True)

    def ucb1_score(self, c_exploration: float = 1.414) -> float:
        """Calculate UCB1 value for this node."""
        if self.visits == 0:
            return float("inf")
        exploitation = self.total_value / self.visits
        exploration = c_exploration * math.sqrt(math.log(self.parent.visits) / self.visits)
        return exploitation + exploration

    def select_best_child(self, c_exploration: float = 1.414) -> "MCTSNode":
        """Select child with highest UCB1 score."""
        return max(self.children.values(), key=lambda node: node.ucb1_score(c_exploration))


class PureMCTSAgent(BaseAgent):
    """
    Pure MCTS Agent without neural network guidance (pure random playouts).
    Balances exploration and exploitation via UCB1.
    """

    def __init__(
        self,
        name: str = "PureMCTSAgent",
        num_simulations: int = 400,
        c_exploration: float = 1.414,
        max_rollout_depth: int = 35,
        player_id=None,
    ):
        super().__init__(name=name, player_id=player_id)
        self.num_simulations = num_simulations
        self.c_exploration = c_exploration
        self.max_rollout_depth = max_rollout_depth

    def _simulate_rollout(self, board: chess.Board) -> float:
        """
        Step 3: Rollout / Playout phase.
        Simulate game with random moves until terminal or max depth.
        Returns outcome from the perspective of root player (White=1, Black=-1, Draw=0).
        """
        sim_board = board.copy(stack=False)
        step = 0

        while not sim_board.is_game_over(claim_draw=True) and step < self.max_rollout_depth:
            moves = list(sim_board.legal_moves)
            if not moves:
                break
            move = random.choice(moves)
            sim_board.push(move)
            step += 1

        outcome = sim_board.outcome(claim_draw=True)
        if outcome is None:
            return 0.0  # Incomplete rollout treated as neutral draw
        if outcome.winner == chess.WHITE:
            return 1.0
        elif outcome.winner == chess.BLACK:
            return -1.0
        return 0.0

    def act(self, board: ChessBoard) -> chess.Move:
        legal_moves = board.legal_moves
        if not legal_moves:
            raise ValueError("No legal moves available!")
        if len(legal_moves) == 1:
            return legal_moves[0]

        root = MCTSNode(board.board.copy())

        for _ in range(self.num_simulations):
            node = root

            # 1. Selection
            while node.is_fully_expanded() and not node.is_terminal():
                if not node.children:
                    break
                node = node.select_best_child(self.c_exploration)

            # 2. Expansion
            if not node.is_terminal() and node.unvisited_moves:
                move = node.unvisited_moves.pop(random.randrange(len(node.unvisited_moves)))
                next_board = node.board.copy()
                next_board.push(move)
                child = MCTSNode(next_board, parent=node, move=move)
                node.children[move] = child
                node = child

            # 3. Rollout / Simulation
            result_white = self._simulate_rollout(node.board)

            # 4. Backpropagation
            # Traverse back up to root. Each node's value is stored relative to its incoming player
            curr: Optional[MCTSNode] = node
            while curr is not None:
                curr.visits += 1
                # If current node's parent was White to move, White's payoff is result_white
                if curr.parent is not None:
                    parent_turn = curr.parent.board.turn
                    value_for_parent = result_white if parent_turn == chess.WHITE else -result_white
                    curr.total_value += value_for_parent
                else:
                    curr.total_value += result_white if root.board.turn == chess.WHITE else -result_white
                curr = curr.parent

        # Select action with maximum visit count
        best_move = max(root.children.items(), key=lambda item: item[1].visits)[0]
        return best_move
