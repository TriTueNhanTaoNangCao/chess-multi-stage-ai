"""
Stage 2: MinimaxAgent with Depth Pruning.
Concepts from Mark Liu (2025) Chapters 4, 5, & 7:
- Recursive game tree exploration.
- Depth pruning when depth reaches 0.
- Position evaluation using static Material + PST heuristic.
"""

from typing import Optional, Tuple
import chess
from agents.base import BaseAgent
from agents.stage1_heuristics.pst import evaluate_relative
from games.chess.board import ChessBoard


class MinimaxAgent(BaseAgent):
    """
    Minimax search agent with depth pruning.
    Uses Negamax formulation for elegance and symmetry.
    """

    def __init__(self, name: str = "MinimaxAgent", depth: int = 3, player_id=None):
        super().__init__(name=name, player_id=player_id)
        self.depth = depth
        self.nodes_visited = 0

    def _negamax(self, board: chess.Board, depth: int) -> int:
        """Recursive negamax search."""
        self.nodes_visited += 1

        if board.is_checkmate():
            return -30000 + (self.depth - depth)  # Prefer faster checkmates
        if board.is_stalemate() or board.can_claim_draw() or board.is_insufficient_material():
            return 0
        if depth == 0:
            return evaluate_relative(board)

        best_val = -float("inf")
        for move in board.legal_moves:
            board.push(move)
            val = -self._negamax(board, depth - 1)
            board.pop()
            if val > best_val:
                best_val = val

        return int(best_val)

    def act(self, board: ChessBoard) -> chess.Move:
        legal_moves = board.legal_moves
        if not legal_moves:
            raise ValueError("No legal moves available!")

        self.nodes_visited = 0
        best_move = legal_moves[0]
        best_val = -float("inf")

        for move in legal_moves:
            board.board.push(move)
            val = -self._negamax(board.board, self.depth - 1)
            board.board.pop()

            if val > best_val:
                best_val = val
                best_move = move

        return best_move
