"""
Stage 5: Value Network for Chess Position Evaluation.
Architectural reference: Silver et al. (Nature 2016, 2017), Mark Liu (2025) Chapter 13 & 15.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from games.chess.encoder import NUM_CHANNELS


class ValueNetwork(nn.Module):
    """
    Evaluates board position s to output scalar value v in [-1, 1]
    representing expected game outcome z from current player's perspective.
    """

    def __init__(self, in_channels: int = NUM_CHANNELS, hidden_dim: int = 128):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, hidden_dim, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(hidden_dim)

        self.conv2 = nn.Conv2d(hidden_dim, 64, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(64)

        self.conv_val = nn.Conv2d(64, 1, kernel_size=1)
        self.bn_val = nn.BatchNorm2d(1)

        self.fc1 = nn.Linear(8 * 8, 256)
        self.fc2 = nn.Linear(256, 64)
        self.fc3 = nn.Linear(64, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass.
        Returns value tensor of shape (B, 1) with values in range [-1.0, 1.0].
        """
        out = F.relu(self.bn1(self.conv1(x)))
        out = F.relu(self.bn2(self.conv2(out)))

        out = F.relu(self.bn_val(self.conv_val(out)))
        out = out.reshape(out.size(0), -1)

        out = F.relu(self.fc1(out))
        out = F.relu(self.fc2(out))
        val = torch.tanh(self.fc3(out))
        return val
