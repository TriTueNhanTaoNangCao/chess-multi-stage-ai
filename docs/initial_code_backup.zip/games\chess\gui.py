"""
Modern, responsive Pygame GUI for Chess Multi-Stage AI.
Features:
- Premium aesthetics (Nordic / Slate theme, smooth anti-aliased glyphs)
- Interactive drag-and-drop or click-to-move
- Translucent legal move hints and selection highlights
- Check and checkmate indicators
- Side panel with move history, turn indicator, material balance, and evaluation
- Human vs AI, AI vs AI, Human vs Human modes
"""

import sys
import os
from typing import List, Optional, Tuple, Callable
import chess
import pygame

# Colors - Premium Nordic Palette
COLOR_LIGHT_SQ = (238, 238, 210)       # Warm ivory
COLOR_DARK_SQ = (118, 150, 86)         # Olive forest
COLOR_SELECTED = (186, 202, 43, 180)   # Translucent lime
COLOR_LAST_MOVE = (246, 246, 105, 120) # Soft yellow
COLOR_HINT = (100, 100, 100, 100)      # Translucent gray dot
COLOR_CHECK = (235, 60, 60, 200)       # Crimson glow
COLOR_BG_PANEL = (30, 34, 42)          # Deep slate dark
COLOR_CARD = (40, 44, 52)              # Card dark
COLOR_ACCENT = (97, 175, 239)          # Cyber blue
COLOR_TEXT_PRIMARY = (235, 240, 245)
COLOR_TEXT_MUTED = (150, 155, 165)
COLOR_WHITE_PIECE = (255, 255, 255)
COLOR_WHITE_PIECE_OUTLINE = (40, 40, 40)
COLOR_BLACK_PIECE = (32, 34, 38)
COLOR_BLACK_PIECE_OUTLINE = (220, 220, 220)

PIECE_UNICODE = {
    chess.Piece(chess.PAWN, chess.WHITE): "♙",
    chess.Piece(chess.KNIGHT, chess.WHITE): "♘",
    chess.Piece(chess.BISHOP, chess.WHITE): "♗",
    chess.Piece(chess.ROOK, chess.WHITE): "♖",
    chess.Piece(chess.QUEEN, chess.WHITE): "♕",
    chess.Piece(chess.KING, chess.WHITE): "♔",
    chess.Piece(chess.PAWN, chess.BLACK): "♟",
    chess.Piece(chess.KNIGHT, chess.BLACK): "♞",
    chess.Piece(chess.BISHOP, chess.BLACK): "♝",
    chess.Piece(chess.ROOK, chess.BLACK): "♜",
    chess.Piece(chess.QUEEN, chess.BLACK): "♛",
    chess.Piece(chess.KING, chess.BLACK): "♚",
}


class ChessGUI:
    """Interactive Graphical User Interface built on Pygame."""

    def __init__(
        self,
        board_size: int = 640,
        panel_width: int = 340,
        title: str = "Chess Multi-Stage AI (AlphaZero Paradigm)",
    ):
        pygame.init()
        pygame.display.set_caption(title)

        self.board_size = board_size
        self.panel_width = panel_width
        self.sq_size = board_size // 8
        self.width = board_size + panel_width
        self.height = board_size

        self.screen = pygame.display.set_mode((self.width, self.height))
        self.clock = pygame.time.Clock()

        # Fonts
        self.piece_font = self._find_piece_font(int(self.sq_size * 0.78))
        self.font_large = pygame.font.SysFont("segoeui,arial", 22, bold=True)
        self.font_medium = pygame.font.SysFont("segoeui,arial", 16)
        self.font_small = pygame.font.SysFont("segoeui,arial", 13)

        self.selected_sq: Optional[chess.Square] = None
        self.legal_destinations: List[chess.Square] = []
        self.last_move: Optional[chess.Move] = None
        self.move_history: List[str] = []

    def _find_piece_font(self, size: int) -> pygame.font.Font:
        candidates = ["segoeuisymbol", "segoeuihistoric", "arial", "dejavusans", "freesans"]
        for name in candidates:
            try:
                font = pygame.font.SysFont(name, size)
                # Test render
                test = font.render("♔", True, (255, 255, 255))
                if test.get_width() > 10:
                    return font
            except Exception:
                continue
        return pygame.font.SysFont(None, size)

    def square_to_screen(self, sq: chess.Square) -> Tuple[int, int]:
        """Convert chess square (0..63) to top-left screen (x, y)."""
        file_idx = chess.square_file(sq)
        rank_idx = 7 - chess.square_rank(sq)
        return file_idx * self.sq_size, rank_idx * self.sq_size

    def screen_to_square(self, x: int, y: int) -> Optional[chess.Square]:
        """Convert screen (x, y) to chess.Square, or None if outside board."""
        if x < 0 or x >= self.board_size or y < 0 or y >= self.board_size:
            return None
        file_idx = x // self.sq_size
        rank_idx = 7 - (y // self.sq_size)
        return chess.square(file_idx, rank_idx)

    def draw_board(self, board: chess.Board) -> None:
        """Draw 64 squares with coordinates and highlights."""
        check_sq = board.king(board.turn) if board.is_check() else None

        for r in range(8):
            for c in range(8):
                sq = chess.square(c, 7 - r)
                x = c * self.sq_size
                y = r * self.sq_size

                # Base tile
                is_light = (r + c) % 2 == 0
                bg = COLOR_LIGHT_SQ if is_light else COLOR_DARK_SQ
                pygame.draw.rect(self.screen, bg, (x, y, self.sq_size, self.sq_size))

                # Last move highlight
                if self.last_move and sq in (self.last_move.from_square, self.last_move.to_square):
                    overlay = pygame.Surface((self.sq_size, self.sq_size), pygame.SRCALPHA)
                    overlay.fill(COLOR_LAST_MOVE)
                    self.screen.blit(overlay, (x, y))

                # Selected square highlight
                if self.selected_sq == sq:
                    overlay = pygame.Surface((self.sq_size, self.sq_size), pygame.SRCALPHA)
                    overlay.fill(COLOR_SELECTED)
                    self.screen.blit(overlay, (x, y))

                # Check on king alert
                if sq == check_sq:
                    overlay = pygame.Surface((self.sq_size, self.sq_size), pygame.SRCALPHA)
                    overlay.fill(COLOR_CHECK)
                    self.screen.blit(overlay, (x, y))

                # Coordinates on borders
                if c == 0:
                    lbl = self.font_small.render(str(8 - r), True, COLOR_DARK_SQ if is_light else COLOR_LIGHT_SQ)
                    self.screen.blit(lbl, (x + 3, y + 3))
                if r == 7:
                    lbl = self.font_small.render(chr(ord('a') + c), True, COLOR_DARK_SQ if is_light else COLOR_LIGHT_SQ)
                    self.screen.blit(lbl, (x + self.sq_size - 13, y + self.sq_size - 16))

        # Legal move hints
        for dest in self.legal_destinations:
            dx, dy = self.square_to_screen(dest)
            center = (dx + self.sq_size // 2, dy + self.sq_size // 2)
            hint_surf = pygame.Surface((self.sq_size, self.sq_size), pygame.SRCALPHA)
            target_piece = board.piece_at(dest)
            if target_piece:
                # Hollow ring for capture
                pygame.draw.circle(hint_surf, (180, 50, 50, 160), (self.sq_size // 2, self.sq_size // 2), self.sq_size // 2 - 4, 6)
            else:
                # Small solid circle for move
                pygame.draw.circle(hint_surf, COLOR_HINT, (self.sq_size // 2, self.sq_size // 2), self.sq_size // 6)
            self.screen.blit(hint_surf, (dx, dy))

    def draw_pieces(self, board: chess.Board) -> None:
        """Render piece unicode glyphs on top of tiles."""
        for sq in range(64):
            piece = board.piece_at(sq)
            if not piece:
                continue
            x, y = self.square_to_screen(sq)
            sym = PIECE_UNICODE.get(piece, piece.symbol())

            # Render text glyph with shadow for legibility
            color_fg = COLOR_WHITE_PIECE if piece.color == chess.WHITE else COLOR_BLACK_PIECE
            color_border = COLOR_WHITE_PIECE_OUTLINE if piece.color == chess.WHITE else COLOR_BLACK_PIECE_OUTLINE

            # Draw crisp outline
            for ox, oy in [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (1, 1)]:
                out_surf = self.piece_font.render(sym, True, color_border)
                out_rect = out_surf.get_rect(center=(x + self.sq_size // 2 + ox, y + self.sq_size // 2 + oy))
                self.screen.blit(out_surf, out_rect)

            surf = self.piece_font.render(sym, True, color_fg)
            rect = surf.get_rect(center=(x + self.sq_size // 2, y + self.sq_size // 2))
            self.screen.blit(surf, rect)

    def draw_panel(
        self,
        board: chess.Board,
        white_name: str,
        black_name: str,
        eval_score: Optional[float] = None,
    ) -> None:
        """Render side panel with rich game status and move list."""
        panel_rect = pygame.Rect(self.board_size, 0, self.panel_width, self.height)
        pygame.draw.rect(self.screen, COLOR_BG_PANEL, panel_rect)

        # Header card
        header_rect = pygame.Rect(self.board_size + 15, 15, self.panel_width - 30, 80)
        pygame.draw.rect(self.screen, COLOR_CARD, header_rect, border_radius=8)

        t_title = self.font_large.render("CHESS AI ARENA", True, COLOR_ACCENT)
        self.screen.blit(t_title, (header_rect.x + 12, header_rect.y + 10))

        stage_subtitle = self.font_small.render("7-Stage Evolutionary Architecture", True, COLOR_TEXT_MUTED)
        self.screen.blit(stage_subtitle, (header_rect.x + 12, header_rect.y + 42))

        # Players Box
        p_box = pygame.Rect(self.board_size + 15, 110, self.panel_width - 30, 95)
        pygame.draw.rect(self.screen, COLOR_CARD, p_box, border_radius=8)

        # White status
        w_active = "● " if board.turn == chess.WHITE and not board.is_game_over() else "  "
        w_col = (100, 220, 100) if board.turn == chess.WHITE else COLOR_TEXT_PRIMARY
        txt_w = self.font_medium.render(f"{w_active}White: {white_name}", True, w_col)
        self.screen.blit(txt_w, (p_box.x + 12, p_box.y + 12))

        # Black status
        b_active = "● " if board.turn == chess.BLACK and not board.is_game_over() else "  "
        b_col = (100, 220, 100) if board.turn == chess.BLACK else COLOR_TEXT_PRIMARY
        txt_b = self.font_medium.render(f"{b_active}Black: {black_name}", True, b_col)
        self.screen.blit(txt_b, (p_box.x + 12, p_box.y + 40))

        # Game status badge
        if board.is_checkmate():
            winner = "White" if board.turn == chess.BLACK else "Black"
            stat_msg = f"Checkmate! {winner} Wins!"
            badge_col = (235, 75, 75)
        elif board.is_stalemate():
            stat_msg = "Stalemate - Draw!"
            badge_col = (230, 180, 50)
        elif board.is_game_over():
            stat_msg = "Game Over - Draw!"
            badge_col = (200, 200, 200)
        elif board.is_check():
            stat_msg = "Check!"
            badge_col = (235, 75, 75)
        else:
            stat_msg = f"Turn: {board.fullmove_number} ({'White' if board.turn == chess.WHITE else 'Black'})"
            badge_col = COLOR_ACCENT

        txt_stat = self.font_medium.render(stat_msg, True, badge_col)
        self.screen.blit(txt_stat, (p_box.x + 12, p_box.y + 68))

        # Move History Box
        hist_box = pygame.Rect(self.board_size + 15, 220, self.panel_width - 30, self.height - 235)
        pygame.draw.rect(self.screen, COLOR_CARD, hist_box, border_radius=8)

        lbl_hist = self.font_medium.render("Move History", True, COLOR_TEXT_MUTED)
        self.screen.blit(lbl_hist, (hist_box.x + 12, hist_box.y + 10))

        # Render recent moves in pairs
        start_y = hist_box.y + 36
        moves = list(board.move_stack)
        num_moves = len(moves)
        max_rows = (hist_box.height - 45) // 22

        # Show the most recent moves
        first_row = max(0, (num_moves + 1) // 2 - max_rows)
        row = 0
        for i in range(first_row * 2, num_moves, 2):
            if row >= max_rows:
                break
            move_num = i // 2 + 1
            w_mv = board.san(moves[i]) if i < num_moves else ""
            b_mv = board.san(moves[i + 1]) if i + 1 < num_moves else ""
            line_str = f"{move_num:2d}. {w_mv:<7} {b_mv}"
            txt_line = self.font_small.render(line_str, True, COLOR_TEXT_PRIMARY)
            self.screen.blit(txt_line, (hist_box.x + 12, start_y + row * 22))
            row += 1

    def handle_click(
        self,
        board: chess.Board,
        x: int,
        y: int,
        on_move_made: Optional[Callable[[chess.Move], None]] = None,
    ) -> Optional[chess.Move]:
        """Handle mouse click for interactive moves."""
        sq = self.screen_to_square(x, y)
        if sq is None:
            self.selected_sq = None
            self.legal_destinations = []
            return None

        # If a square was already selected, check if clicked square is destination
        if self.selected_sq is not None:
            chosen_move: Optional[chess.Move] = None

            # Look for exact move or promotion to Queen by default
            candidate = chess.Move(self.selected_sq, sq)
            candidate_promo = chess.Move(self.selected_sq, sq, promotion=chess.QUEEN)

            if candidate in board.legal_moves:
                chosen_move = candidate
            elif candidate_promo in board.legal_moves:
                chosen_move = candidate_promo

            if chosen_move is not None:
                self.selected_sq = None
                self.legal_destinations = []
                self.last_move = chosen_move
                if on_move_made:
                    on_move_made(chosen_move)
                return chosen_move

        # Otherwise select clicked piece if it belongs to player to move
        piece = board.piece_at(sq)
        if piece and piece.color == board.turn:
            self.selected_sq = sq
            self.legal_destinations = [
                m.to_square for m in board.legal_moves if m.from_square == sq
            ]
        else:
            self.selected_sq = None
            self.legal_destinations = []
        return None

    def render(
        self,
        board: chess.Board,
        white_name: str = "Player 1",
        black_name: str = "Player 2",
        eval_score: Optional[float] = None,
    ) -> None:
        """Draw full GUI frame and flip display."""
        self.screen.fill(COLOR_BG_PANEL)
        self.draw_board(board)
        self.draw_pieces(board)
        self.draw_panel(board, white_name, black_name, eval_score)
        pygame.display.flip()
        self.clock.tick(60)

    def close(self) -> None:
        pygame.quit()
