"""
Human Agent supporting interactive CLI move input via SAN or UCI.
"""

import chess
from agents.base import BaseAgent
from games.chess.board import ChessBoard


class HumanAgent(BaseAgent):
    """Allows a human player to enter moves via CLI (SAN or UCI format)."""

    def __init__(self, name: str = "Human", player_id=None):
        super().__init__(name=name, player_id=player_id)

    def act(self, board: ChessBoard) -> chess.Move:
        legal_ucis = [m.uci() for m in board.legal_moves]
        legal_sans = [board.san(m) for m in board.legal_moves]

        while True:
            try:
                user_input = input(f"[{self.name} ({board.turn_name})] Enter move (SAN like 'Nf3' or UCI like 'g1f3'): ").strip()
                if not user_input:
                    continue

                # Check SAN
                if user_input in legal_sans:
                    return board.parse_san(user_input)

                # Check UCI
                if user_input in legal_ucis:
                    return board.parse_uci(user_input)

                # Try parsing as SAN with loose casing
                try:
                    move = board.parse_san(user_input)
                    if move in board.legal_moves:
                        return move
                except ValueError:
                    pass

                print(f"Invalid move '{user_input}'. Legal options include: {', '.join(legal_sans[:8])}...")
            except (EOFError, KeyboardInterrupt):
                # Fallback to random if input stream closed
                import random
                return random.choice(board.legal_moves)
