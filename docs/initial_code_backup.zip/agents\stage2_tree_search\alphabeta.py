"""
Stage 2: AlphaBetaAgent with Alpha-Beta Pruning, Move Ordering, and Quiescence Search.
Concept from Mark Liu (2025) Chapter 6 & DeepMind 2017:
- Alpha-Beta branch pruning.
- Move Ordering (MVV-LVA Captures, Promotions, Checks).
- Quiescence Search (Resolves tactical captures at depth 0 to avoid Horizon Effect).
"""

from typing import List, Tuple
import chess
from agents.base import BaseAgent
from agents.stage1_heuristics.pst import PIECE_VALUES, evaluate_relative
from games.chess.board import ChessBoard


class AlphaBetaAgent(BaseAgent):
    """
    Alpha-Beta search agent with Move Ordering and Quiescence Search.
    Significantly faster and deeper search capability than plain Minimax.
    """

    def __init__(
        self,
        name: str = "AlphaBetaAgent",
        depth: int = 3,
        use_quiescence: bool = True,
        player_id=None,
    ):
        super().__init__(name=name, player_id=player_id)
        self.depth = depth
        self.use_quiescence = use_quiescence
        self.nodes_visited = 0
        self.cutoffs = 0

    def _score_move_for_ordering(self, board: chess.Board, move: chess.Move) -> int:
        """Score moves to place promising variations first for maximum cutoffs."""
        # 1. Winning and favorable captures (MVV-LVA)
        if board.is_capture(move):
            if board.is_en_passant(move):
                victim_type = chess.PAWN
            else:
                victim_piece = board.piece_at(move.to_square)
                victim_type = victim_piece.piece_type if victim_piece else chess.PAWN

            attacker_piece = board.piece_at(move.from_square)
            attacker_type = attacker_piece.piece_type if attacker_piece else chess.PAWN

            victim_val = PIECE_VALUES.get(victim_type, 0)
            attacker_val = PIECE_VALUES.get(attacker_type, 0)
            return 10000 + (10 * victim_val - attacker_val)

        # 2. Pawn Promotion
        if move.promotion:
            return 9000 + PIECE_VALUES.get(move.promotion, 0)

        # 3. Direct Checks
        board.push(move)
        gives_check = board.is_check()
        board.pop()
        if gives_check:
            return 5000

        # 4. Quiet moves
        return 0

    def _order_moves(self, board: chess.Board, moves: List[chess.Move]) -> List[chess.Move]:
        """Order moves descending by prospective tactical score."""
        return sorted(moves, key=lambda m: self._score_move_for_ordering(board, m), reverse=True)

    def _quiescence_search(self, board: chess.Board, alpha: int, beta: int, q_depth: int = 4) -> int:
        """
        Quiescence Search:
        Continues searching only capture moves until a calm position is reached.
        Prevents the Horizon Effect where bad tactical exchanges are hidden beyond horizon.
        """
        self.nodes_visited += 1

        stand_pat = evaluate_relative(board)

        # Beta cutoff
        if stand_pat >= beta:
            return beta
        if alpha < stand_pat:
            alpha = stand_pat

        if q_depth == 0:
            return alpha

        # Generate and order only capture moves
        captures = [m for m in board.legal_moves if board.is_capture(m)]
        ordered_captures = self._order_moves(board, captures)

        for move in ordered_captures:
            board.push(move)
            score = -self._quiescence_search(board, -beta, -alpha, q_depth - 1)
            board.pop()

            if score >= beta:
                self.cutoffs += 1
                return beta
            if score > alpha:
                alpha = score

        return alpha

    def _search(self, board: chess.Board, depth: int, alpha: int, beta: int) -> int:
        """Negamax search with Alpha-Beta pruning."""
        self.nodes_visited += 1

        if board.is_checkmate():
            return -30000 + (self.depth - depth)
        if board.is_stalemate() or board.can_claim_draw() or board.is_insufficient_material():
            return 0

        if depth == 0:
            if self.use_quiescence:
                return self._quiescence_search(board, alpha, beta)
            return evaluate_relative(board)

        ordered_moves = self._order_moves(board, list(board.legal_moves))
        for move in ordered_moves:
            board.push(move)
            val = -self._search(board, depth - 1, -beta, -alpha)
            board.pop()

            if val >= beta:
                self.cutoffs += 1
                return beta
            if val > alpha:
                alpha = val

        return alpha

    def act(self, board: ChessBoard) -> chess.Move:
        legal_moves = board.legal_moves
        if not legal_moves:
            raise ValueError("No legal moves available!")

        self.nodes_visited = 0
        self.cutoffs = 0

        alpha = -float("inf")
        beta = float("inf")

        best_move = legal_moves[0]
        ordered_moves = self._order_moves(board.board, legal_moves)

        for move in ordered_moves:
            board.board.push(move)
            val = -self._search(board.board, self.depth - 1, -beta, -alpha)
            board.board.pop()

            if val > alpha:
                alpha = val
                best_move = move

        return best_move
