"""
Chess state and action space encoder/decoder according to DeepMind AlphaZero (2017) specifications.

State Tensor:
- Shape: (18, 8, 8)
  - 0-5:   Current player's pieces (P, N, B, R, Q, K)
  - 6-11:  Opponent's pieces (P, N, B, R, Q, K)
  - 12:    Current player Kingside castling right
  - 13:    Current player Queenside castling right
  - 14:    Opponent Kingside castling right
  - 15:    Opponent Queenside castling right
  - 16:    Normalized halfmove clock (50-move rule counter / 100.0)
  - 17:    Side to move (1.0 for White, 0.0 for Black)
  
Player-Independent Perspective:
- When Black is to play, the board is flipped vertically (rank 7 - r) so current player
  always plays from bottom (rank 0-1) towards top (rank 7).

Action Space:
- Size: 8 * 8 * 73 = 4,672 actions
  - 56 queen moves (8 directions x 7 distances)
  - 8 knight moves
  - 9 underpromotions (3 directions: straight, left capture, right capture x 3 pieces: N, B, R)
  (Queen promotions are absorbed into standard 1-step queen moves).
"""

from typing import Dict, List, Optional, Tuple
import chess
import numpy as np
import torch

NUM_ACTIONS = 4672  # 8 * 8 * 73
NUM_CHANNELS = 18

# Queen move directions: (delta_rank, delta_file)
# N, NE, E, SE, S, SW, W, NW (relative to current player looking forward)
QUEEN_DIRECTIONS = [
    (1, 0),   # N
    (1, 1),   # NE
    (0, 1),   # E
    (-1, 1),  # SE
    (-1, 0),  # S
    (-1, -1), # SW
    (0, -1),  # W
    (1, -1),  # NW
]

# Knight move offsets: (delta_rank, delta_file)
KNIGHT_OFFSETS = [
    (2, 1),
    (1, 2),
    (-1, 2),
    (-2, 1),
    (-2, -1),
    (-1, -2),
    (1, -2),
    (2, -1),
]

# Underpromotion directions: (delta_file) - left capture (-1), straight (0), right capture (+1)
UNDERPROMOTION_PIECES = [chess.KNIGHT, chess.BISHOP, chess.ROOK]


def _build_action_mappings():
    """Build precalculated dictionaries mapping between (from_sq, move_type) and action_idx."""
    move_to_idx: Dict[Tuple[int, int, Optional[int]], int] = {}
    idx_to_move_spec: Dict[int, Tuple[int, int, Optional[int]]] = {}

    for from_sq in range(64):
        from_rank = from_sq // 8
        from_file = from_sq % 8

        plane_idx = 0

        # 1. 56 Queen moves
        for d_idx, (dr, df) in enumerate(QUEEN_DIRECTIONS):
            for dist in range(1, 8):
                to_rank = from_rank + dr * dist
                to_file = from_file + df * dist
                action_idx = from_sq * 73 + plane_idx
                if 0 <= to_rank < 8 and 0 <= to_file < 8:
                    to_sq = to_rank * 8 + to_file
                    move_to_idx[(from_sq, to_sq, None)] = action_idx
                    idx_to_move_spec[action_idx] = (from_sq, to_sq, None)
                plane_idx += 1

        # 2. 8 Knight moves
        for dr, df in KNIGHT_OFFSETS:
            to_rank = from_rank + dr
            to_file = from_file + df
            action_idx = from_sq * 73 + plane_idx
            if 0 <= to_rank < 8 and 0 <= to_file < 8:
                to_sq = to_rank * 8 + to_file
                move_to_idx[(from_sq, to_sq, None)] = action_idx
                idx_to_move_spec[action_idx] = (from_sq, to_sq, None)
            plane_idx += 1

        # 3. 9 Underpromotions (from rank 6 to rank 7 only)
        for df in [-1, 0, 1]:
            for piece in UNDERPROMOTION_PIECES:
                action_idx = from_sq * 73 + plane_idx
                if from_rank == 6:
                    to_file = from_file + df
                    to_rank = 7
                    if 0 <= to_file < 8:
                        to_sq = to_rank * 8 + to_file
                        move_to_idx[(from_sq, to_sq, piece)] = action_idx
                        idx_to_move_spec[action_idx] = (from_sq, to_sq, piece)
                plane_idx += 1

    return move_to_idx, idx_to_move_spec


MOVE_TO_IDX, IDX_TO_MOVE_SPEC = _build_action_mappings()


class ChessEncoder:
    """Encodes and decodes chess positions and actions."""

    @staticmethod
    def encode_board(board: chess.Board) -> np.ndarray:
        """
        Encode chess.Board to (18, 8, 8) numpy float32 array.
        Player-independent: oriented from the perspective of current player.
        """
        planes = np.zeros((NUM_CHANNELS, 8, 8), dtype=np.float32)
        turn = board.turn
        opp_color = not turn

        # Piece planes (0-5 current player, 6-11 opponent)
        piece_order = [
            chess.PAWN,
            chess.KNIGHT,
            chess.BISHOP,
            chess.ROOK,
            chess.QUEEN,
            chess.KING,
        ]

        for p_idx, p_type in enumerate(piece_order):
            for sq in board.pieces(p_type, turn):
                r = sq // 8 if turn == chess.WHITE else 7 - (sq // 8)
                c = sq % 8
                planes[p_idx, r, c] = 1.0

            for sq in board.pieces(p_type, opp_color):
                r = sq // 8 if turn == chess.WHITE else 7 - (sq // 8)
                c = sq % 8
                planes[6 + p_idx, r, c] = 1.0

        # Castling rights
        if turn == chess.WHITE:
            if board.has_kingside_castling_rights(chess.WHITE):
                planes[12, :, :] = 1.0
            if board.has_queenside_castling_rights(chess.WHITE):
                planes[13, :, :] = 1.0
            if board.has_kingside_castling_rights(chess.BLACK):
                planes[14, :, :] = 1.0
            if board.has_queenside_castling_rights(chess.BLACK):
                planes[15, :, :] = 1.0
        else:
            if board.has_kingside_castling_rights(chess.BLACK):
                planes[12, :, :] = 1.0
            if board.has_queenside_castling_rights(chess.BLACK):
                planes[13, :, :] = 1.0
            if board.has_kingside_castling_rights(chess.WHITE):
                planes[14, :, :] = 1.0
            if board.has_queenside_castling_rights(chess.WHITE):
                planes[15, :, :] = 1.0

        # Halfmove clock
        planes[16, :, :] = min(1.0, board.halfmove_clock / 100.0)

        # Color indicator (1.0 White, 0.0 Black)
        if turn == chess.WHITE:
            planes[17, :, :] = 1.0

        return planes

    @staticmethod
    def encode_board_tensor(board: chess.Board, device: Optional[torch.device] = None) -> torch.Tensor:
        """Encode board into PyTorch tensor of shape (1, 18, 8, 8)."""
        arr = ChessEncoder.encode_board(board)
        tensor = torch.from_numpy(arr).unsqueeze(0)
        if device is not None:
            tensor = tensor.to(device)
        return tensor

    @staticmethod
    def orient_square(sq: int, turn: chess.Color) -> int:
        """Flip square vertically if Black is to move."""
        if turn == chess.WHITE:
            return sq
        r = 7 - (sq // 8)
        c = sq % 8
        return r * 8 + c

    @staticmethod
    def encode_move(move: chess.Move, turn: chess.Color) -> int:
        """
        Convert chess.Move to AlphaZero action index in [0..4671].
        Accounts for player orientation.
        """
        from_sq = ChessEncoder.orient_square(move.from_square, turn)
        to_sq = ChessEncoder.orient_square(move.to_square, turn)

        promo = move.promotion
        # Queen promotions count as normal queen moves
        if promo == chess.QUEEN:
            promo = None

        key = (from_sq, to_sq, promo)
        if key in MOVE_TO_IDX:
            return MOVE_TO_IDX[key]

        # Fallback for standard moves
        key_no_promo = (from_sq, to_sq, None)
        if key_no_promo in MOVE_TO_IDX:
            return MOVE_TO_IDX[key_no_promo]

        raise ValueError(f"Unable to encode move: {move.uci()} (key={key})")

    @staticmethod
    def decode_move(action_idx: int, board: chess.Board) -> Optional[chess.Move]:
        """
        Decode action index back to legal chess.Move given current board.
        Returns None if decoded move is invalid or illegal.
        """
        if action_idx not in IDX_TO_MOVE_SPEC:
            return None

        from_sq_oriented, to_sq_oriented, promo = IDX_TO_MOVE_SPEC[action_idx]
        turn = board.turn

        from_sq = ChessEncoder.orient_square(from_sq_oriented, turn)
        to_sq = ChessEncoder.orient_square(to_sq_oriented, turn)

        # Check if this is a pawn promotion to Queen
        piece = board.piece_at(from_sq)
        if (
            promo is None
            and piece is not None
            and piece.piece_type == chess.PAWN
            and (to_sq // 8 == 7 or to_sq // 8 == 0)
        ):
            candidate = chess.Move(from_sq, to_sq, promotion=chess.QUEEN)
            if candidate in board.legal_moves:
                return candidate

        candidate = chess.Move(from_sq, to_sq, promotion=promo)
        if candidate in board.legal_moves:
            return candidate

        return None

    @staticmethod
    def get_legal_action_mask(board: chess.Board) -> np.ndarray:
        """Return boolean/binary mask of shape (4672,) indicating legal actions."""
        mask = np.zeros(NUM_ACTIONS, dtype=np.float32)
        turn = board.turn
        for move in board.legal_moves:
            try:
                idx = ChessEncoder.encode_move(move, turn)
                mask[idx] = 1.0
            except ValueError:
                continue
        return mask

    @staticmethod
    def legal_action_indices(board: chess.Board) -> List[int]:
        """List of valid action indices for current board position."""
        turn = board.turn
        indices = []
        for move in board.legal_moves:
            try:
                idx = ChessEncoder.encode_move(move, turn)
                indices.append(idx)
            except ValueError:
                continue
        return indices
